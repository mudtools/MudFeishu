# 飞书WebSocket客户端重构说明

## 重构概述

原始的 `FeishuWebSocketClient.cs` 文件过于复杂，包含超过1300行代码，缺乏可维护性和代码复用性。重构后的设计采用组件化架构，将功能拆分为多个专注的类。

## 重构架构

### 核心组件

1. **WebSocketConnectionManager** - 连接管理器
   - 负责WebSocket连接的建立、断开和状态管理
   - 处理消息发送和接收的基础逻辑
   - 管理连接重连机制

2. **AuthenticationManager** - 认证管理器
   - 处理WebSocket认证流程
   - 管理认证状态
   - 提供认证结果事件

3. **MessageRouter** - 消息路由器
   - 负责将接收到的消息路由到合适的处理器
   - 支持消息版本检测（v1.0和v2.0）
   - 管理消息处理器的注册和查找

4. **BinaryMessageProcessor** - 二进制消息处理器
   - 处理二进制数据的增量接收
   - 支持ProtoBuf和JSON格式的解析
   - 管理大消息的内存优化

### 消息处理器

5. **IMessageHandler** - 消息处理器接口
   - 定义消息处理器的通用接口
   - 提供基础的消息类型检测和反序列化功能

6. **EventMessageHandler** - 事件消息处理器
   - 专门处理飞书事件消息
   - 支持v1.0和v2.0版本的消息格式
   - 集成事件处理器工厂和ACK确认机制

7. **BasicMessageHandler** - 基础消息处理器
   - 包含Ping/Pong、认证、心跳等基础消息的处理器
   - 每个处理器专注于特定类型的消息

8. **FeishuWebSocketClientRefactored** - 重构后的主客户端
   - 组合上述所有组件
   - 提供与原始客户端相同的外部接口
   - 简化了主要逻辑，提高可读性

## 重构优势

### 1. 可维护性提升
- **单一职责原则**: 每个类只负责一个特定功能
- **代码行数减少**: 主客户端类从1300+行减少到约400行
- **逻辑清晰**: 功能模块化，易于理解和修改

### 2. 代码复用性提升
- **组件化设计**: 各个组件可以独立测试和使用
- **接口抽象**: 消息处理器可以轻松扩展
- **依赖注入友好**: 各组件依赖清晰，便于DI容器管理

### 3. 测试友好
- **单元测试**: 每个组件可以独立测试
- **模拟测试**: 组件间的依赖可以轻松模拟
- **集成测试**: 组件组合测试更加明确

### 4. 扩展性提升
- **新消息类型**: 只需实现IMessageHandler接口
- **新功能**: 可以通过添加新组件实现
- **配置灵活**: 各组件可以独立配置

## 使用方式

### 基本使用（与原始版本相同）
```csharp
var client = new FeishuWebSocketClientRefactored(
    logger, 
    eventHandlerFactory, 
    options);

// 连接和认证
await client.ConnectAsync(endpoint, appAccessToken);

// 订阅事件
client.FeishuEventReceived += (sender, args) => {
    // 处理飞书事件
};
```

### 自定义消息处理器
```csharp
public class CustomMessageHandler : JsonMessageHandler
{
    public CustomMessageHandler(ILogger logger) : base(logger) { }

    public override bool CanHandle(string messageType)
    {
        return messageType == "custom_type";
    }

    public override async Task HandleAsync(string message, CancellationToken cancellationToken = default)
    {
        // 处理自定义消息
        var data = SafeDeserialize<CustomMessage>(message);
        // 处理逻辑...
    }
}

// 注册自定义处理器
client.RegisterMessageProcessor(customHandler);
```

## 文件结构

```
Mud.Feishu.WebSocket/
├── Core/
│   ├── WebSocketConnectionManager.cs     # 连接管理
│   ├── AuthenticationManager.cs         # 认证管理
│   ├── MessageRouter.cs                # 消息路由
│   └── BinaryMessageProcessor.cs        # 二进制处理
├── Handlers/
│   ├── IMessageHandler.cs              # 处理器接口
│   ├── EventMessageHandler.cs           # 事件消息处理
│   └── BasicMessageHandler.cs           # 基础消息处理
├── SocketEventArgs/
│   └── *.cs                           # 事件参数类
├── DataModels/
│   └── *.cs                           # 数据模型
├── FeishuWebSocketClient.cs           # 原始客户端（保留）
└── FeishuWebSocketClientRefactored.cs # 重构后客户端
```

## 迁移指南

### 1. 渐进式迁移
- 保留原始客户端文件，确保向后兼容
- 新功能使用重构后的客户端
- 逐步迁移现有代码到新架构

### 2. 配置更新
```csharp
// 原始配置
var options = new FeishuWebSocketOptions
{
    EnableLogging = true,
    EnableBinaryMessageProcessing = true
    // ... 其他配置
};

// 重构后配置（相同接口）
var options = new FeishuWebSocketOptions
{
    EnableLogging = true,
    EnableBinaryMessageProcessing = true,
    EnableMessageQueue = true,
    EnableMultiHandlerMode = false
    // ... 其他配置保持不变
};
```

### 3. 事件订阅
事件接口保持不变，现有的事件处理代码无需修改：

```csharp
// 这些事件在重构后版本中仍然可用
client.Connected += (s, e) => { /* 连接成功 */ };
client.Disconnected += (s, e) => { /* 连接断开 */ };
client.MessageReceived += (s, e) => { /* 收到消息 */ };
client.Error += (s, e) => { /* 发生错误 */ };
client.Authenticated += (s, e) => { /* 认证成功 */ };
client.FeishuEventReceived += (s, e) => { /* 飞书事件 */ };
client.BinaryMessageReceived += (s, e) => { /* 二进制消息 */ };
```

## 性能优化

1. **内存管理**: 二进制消息处理使用流式处理，避免大内存占用
2. **并发处理**: 消息路由支持异步并发处理
3. **资源释放**: 所有组件正确实现IDisposable接口
4. **错误隔离**: 各组件的错误不会影响其他组件

## 总结

重构后的飞书WebSocket客户端提供了更好的：
- **可维护性**: 代码结构清晰，易于理解和修改
- **可扩展性**: 组件化设计便于功能扩展
- **可测试性**: 各组件可独立测试
- **可复用性**: 组件可在不同场景中复用

同时保持了与原始客户端相同的外部接口，确保现有代码的兼容性。